gcc -c loop.c
gcc -shared -o loop.dll loop.o
rm loop.o
